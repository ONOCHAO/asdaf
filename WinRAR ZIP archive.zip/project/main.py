from utils import Mystat

user1 = Mystat("lysen_km00", "Zef7r2*y")  
print(user1.get_auth()) 
print(user1.get_marks())  


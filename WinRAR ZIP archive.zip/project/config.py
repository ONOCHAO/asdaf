NUM1 = 2
NUM2 = 7

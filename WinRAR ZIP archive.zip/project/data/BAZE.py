import sqlite3

conn = sqlite3.connect("company.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    position TEXT NOT NULL,
    salary INTEGER NOT NULL,
    experience INTEGER NOT NULL
)
""")

cursor.execute("INSERT INTO employees (full_name, position, salary, experience) VALUES ('Александр Александрович', 'Runner', 120000, 2)")
cursor.execute("INSERT INTO employees (full_name, position, salary, experience) VALUES ('Иван Иванович', 'Cleaner', 130000, 4)")


cursor.execute("SELECT * FROM employees")
rows = cursor.fetchall()

for row in rows:
    print(row)





conn.commit()
conn.close()
print("Таблица 'employees' успешно создана!")

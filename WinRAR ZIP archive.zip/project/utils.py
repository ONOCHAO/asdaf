import requests

class Mystat:
    def __init__(self, login, password):
        self.login = login
        self.password = password
        self.token = None

    def get_auth(self):
        url = "https://mapi.itstep.org/v1/mystat/auth/login"
        headers = {"Accept": "application/json"}
        data = {"login": self.login, "password": self.password}

        response = requests.post(url, headers=headers, json=data)

        print(f"Статус-код: {response.status_code}")  
        print(f"Ответ сервера: {response.text}")  

        if response.status_code == 200:
            self.token = response.text.strip()
            return True
        else:
            print("Ошибка входа.")
            return False
    
    def get_marks(self):
        if not self.token:
            success = self.get_auth()
            if not success:
                return False

        url = "https://mapi.itstep.org/v1/mystat/aqtobe/statistic/marks"
        headers = {"Authorization": f"Bearer {self.token}"}

        response = requests.get(url, headers=headers)
        print(f"Статус-код: {response.status_code}")  
        print(f"Ответ сервера: {response.text}")

        return response.text if response.status_code == 200 else False
